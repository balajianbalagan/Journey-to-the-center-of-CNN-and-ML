import datetime
import os
import numpy as np
from flask import Flask
from flask import request
from flask import render_template
from flask import redirect, url_for, session
from flask_mysqldb import MySQL
from werkzeug.utils import secure_filename
import MySQLdb.cursors
import re
import random
from keras.models import load_model
from tensorflow.keras.preprocessing import image
from dotenv import load_dotenv
from azure.storage.blob import BlobServiceClient
load_dotenv()

app = Flask(__name__)
app.secret_key = 'Star_trek_roof_in_that_wraith_of_khan#'

connect_str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
container_name = "scanphotos"
blob_service_client = BlobServiceClient.from_connection_string(connect_str)

app.config['MYSQL_USER'] = "a8c703_balaji7"
app.config['MYSQL_PASSWORD'] = "balaji2003"
app.config['MYSQL_HOST'] = "mysql5035.site4now.net"
app.config['MYSQL_DB'] = "db_a8c703_balaji7"

mysql = MySQL(app)

@app.route('/login/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        # Create variables for easy access
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = %s AND password = %s', (username, password,))
        # Fetch one record and return result
        account = cursor.fetchone()
        cursor.close()
                # If account exists in accounts table in out database
        if account:
            # Create session data, we can access this data in other routes
            session['loggedin'] = True
            session['id'] = account['id']
            session['username'] = account['username']
            # Redirect to home page
            return redirect(url_for('dashboard'))
        else:
            # Account doesnt exist or username/password incorrect
           return redirect(url_for('login'))
    return render_template('login.html', msg='')

# http://localhost:5000/python/logout - this will be the logout page
@app.route('/logout')
def logout():
    # Remove session data, this will log the user out
   session.pop('loggedin', None)
   session.pop('id', None)
   session.pop('username', None)
   # Redirect to login page
   return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    # Output message if something goes wrong...
    msg = ''
    # Check if "username", "password" and "email" POST requests exist (user submitted form)
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form:
        # Create variables for easy access
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
                # Check if account exists using MySQL
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = %s', (username,))
        account = cursor.fetchone()
        cursor.close()
        # If account exists show error and validation checks
        if account:
            msg = 'Account already exists!'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'Invalid email address!'
        elif not re.match(r'[A-Za-z0-9]+', username):
            msg = 'Username must contain only characters and numbers!'
        elif not username or not password or not email:
            msg = 'Please fill out the form!'
        else:
            # Account doesnt exists and the form data is valid, now insert new account into accounts table
            cursor.execute('INSERT INTO accounts VALUES (NULL, %s, %s, %s)', (username, password, email,))
            mysql.connection.commit()
            msg = 'You have successfully registered!'
    elif request.method == 'POST':
        # Form is empty... (no POST data)
        msg = 'Please fill out the form!'
    # Show registration form with message (if any)
    return render_template('register.html', msg=msg)

@app.route("/predict",methods=["GET","POST"])
def predict():
    if 'loggedin' in session:
        if request.method == "POST":
            pid = request.form["pid"]
            mid1=0
            cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
            cursor.execute('SELECT * FROM patient WHERE pid = %s', (pid,))
            patient = cursor.fetchone()
            if patient==None:
                cursor.execute('INSERT INTO patient (pid,did,startoftreatment,contact,pname) VALUES (%s, %s, %s, %s,%s)', 
                (pid, session['id'] , datetime.datetime.now() ,request.form["pcont"],request.form["pname"]))
                mysql.connection.commit()
            image_file = request.files["image"]
            predtext = ""
            if image_file:
                filename = str(random.random()*92139929)+secure_filename(image_file.filename)
                image_location = os.path.join(
                            os.getenv("UPLOAD_FOLDER"),
                            filename
                )
                image_file.save(image_location)
                subcomm = ""
                if request.form["comment"]:
                    subcomm = request.form["comment"]
                blob_client = blob_service_client.get_blob_client(container = 'scanphotos', blob = filename)
                imagelink = ""
                with open(image_location, "rb") as data:
                    try:
                        blob_client.upload_blob(data, overwrite=True)
                        imagelink = blob_client.url
                        print("Upload Done ! ",)
                    except:
                        print("error uploading azure!!!!!")
                if request.form["models"]=="thyroidbinary":
                    mid1=1
                    img = image.load_img(image_location,target_size=(200,200))
                    model = load_model('./thyroidbin.h5')
                    x = image.img_to_array(img)
                    x = np.expand_dims(x,axis=0)
                    images = np.vstack([x])
                    predval = model.predict(images)
                    x = np.argmax(predval, axis=-1)
                    
                    if(x==0):
                        predtext="benign"
                    else:
                        predtext="malignant"
                elif request.form["models"]=="thyroidmulticlass":
                    mid1=2
                    img = image.load_img(image_location,target_size=(224,224))
                    model = load_model('./multiclass_vgg.h5')
                    x = image.img_to_array(img)
                    x = np.expand_dims(x,axis=0)
                    images = np.vstack([x])
                    predval = model.predict(images)
                    x = np.argmax(predval, axis=-1)
                    if(x==0):
                        predtext="TR3"
                    elif(x==1):
                        predtext="TR4"
                    elif(x==2):
                        predtext="TR1"
                    elif(x==3):
                        predtext="TR5"
                    elif(x==4):
                        predtext="TR2"
                os.remove(image_location)
            sq = ("INSERT INTO submissions (pid,mid,timeofsubmission,result,comments,imagelink) VALUES (%s,%s,%s,%s,%s,%s) ")
            val = (pid ,mid1, datetime.datetime.now() ,predtext,subcomm,imagelink)
            cursor.execute(sq, val)
            mysql.connection.commit()
            cursor.close()
            return render_template("predict.html",prediction=predtext,user_image = imagelink)
        return render_template("predict.html", prediction=0,user_image = './static/icons/drop.png')
    return redirect(url_for('login'))

@app.route('/profile')
def profile():
    # Check if user is loggedin
    if 'loggedin' in session:
        # We need all the account info for the user so we can display it on the profile page
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE id = %s', (session['id'],))
        account = cursor.fetchone()
        cursor.close()
        # Show the profile page with account info
        return render_template('profile.html', account=account)
    # User is not loggedin redirect to login page
    return redirect(url_for('login'))

# http://localhost:5000/- this will be the home page, only accessible for loggedin users
@app.route('/')
def home():
    # Check if user is loggedin
    if 'loggedin' in session:
        # User is loggedin show them the home page
        return redirect(url_for('dashboard'))
    # User is not loggedin redirect to login page
    return redirect(url_for('login'))
    
@app.route('/home')
def home1():
    # Check if user is loggedin
    if 'loggedin' in session:
        # User is loggedin show them the home page
        return redirect(url_for('dashboard'))
    # User is not loggedin redirect to login page
    return redirect(url_for('login'))

@app.route('/feedback/<int:sid>',methods=["POST"])
def feedback(sid):
    if 'loggedin' in session:
        pid1 = int(request.form['pid'])
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        isc = False
        if(request.form['feedbackval']==request.form['predictval']):
            isc = True
        sq = ("INSERT INTO feedback (sid,actualvalue,predictedvalue,iscorrect,imagelink) VALUES (%s,%s,%s,%s,%s) ")
        val = (sid ,request.form['feedbackval'], request.form['predictval'],isc ,request.form['imagelink'])
        cursor.execute(sq, val)
        mysql.connection.commit()
        cursor.close()
                

        return redirect(url_for('viewpatient',pid=pid1))
    return redirect(url_for('login'))
# sid
# actualvalue
# predictedvalue
# iscorrect
# imagelink
@app.route('/dashboard')
def dashboard():
    # Check if user is loggedin
    if 'loggedin' in session:
        # User is loggedin show them the home page
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM patient WHERE did = %s ', (session['id'],))
        rows = cursor.fetchall()
        cursor.close()
        return render_template('dashboard.html', username=session['username'],prows = rows)
    # User is not loggedin redirect to login page
    return redirect(url_for('login'))

@app.route('/addpatient',methods=["POST"])
def addpatient():
    if 'loggedin' in session and request.method == 'POST':
        # User is loggedin show them the home page
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('INSERT INTO patient (did,startoftreatment,contact,pname) VALUES (%s, %s, %s,%s)', ( session['id'] , datetime.datetime.now() ,request.form["pcont"],request.form["pname"]))
        mysql.connection.commit()
        cursor.close()
        return redirect(url_for('dashboard'))
    # User is not loggedin redirect to login page
    return redirect(url_for('login'))


@app.route('/viewpatient/<int:pid>')
def viewpatient(pid):
    # Check if user is loggedin
    if 'loggedin' in session:
        # User is loggedin show them the home page
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM submissions INNER JOIN models ON submissions.mid=models.mid INNER JOIN patient ON submissions.pid=patient.pid AND submissions.pid = %s ORDER BY submissions.timeofsubmission DESC',(pid,))
        rows = cursor.fetchall()
        for i in rows:
            cursor.execute('SELECT * FROM parameters WHERE mid=%s',(i['mid'],))
            params = cursor.fetchall()
            i['params']=params
            cursor.execute('SELECT * FROM feedback WHERE sid=%s',(i['sid'],))
            faval = cursor.fetchone()
            if faval:
                i['faval']=1
            else:
                i['faval']=0
        print(rows)
        cursor.close()
        return render_template('patientinfo.html', username=session['username'],prows = rows)
    # User is not loggedin redirect to login page
    return redirect(url_for('login'))


if __name__ == "__main__":
    app.run(port=12000,debug=True)

